#include <stdio.h>

int main() {
    int jugadores[j];
    int j = 5;  
    
    printf("Introduce 5 valores para el jugadores:\n");
    for (int i = 0; i < 5; i++) {
        printf("Valor para jugadores[%d]: ", i);
        scanf("%d", &jugadores[i]);
    }
    return 0;

}